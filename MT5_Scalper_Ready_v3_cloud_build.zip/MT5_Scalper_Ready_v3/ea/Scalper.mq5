#property strict
#property version "3.00"
#include <Trade/Trade.mqh>
CTrade trade;
input double RiskPercent=0.01;
input int MaxSpreadPoints=35;
input int StopLossPoints=250;
input int TakeProfitPoints=350;
input int FastEMA=9;
input int SlowEMA=21;
input int RSIPeriod=14;
input int BreakoutLookback=12;
input int MinVotes=2;
input bool UseEMA=true;
input bool UseRSI=true;
input bool UseMACD=true;
input bool UseBollinger=true;
input bool UseBreakout=true;
input ulong Magic=20261019;
input string Symbols="XAUUSD,EURUSD,GBPUSD,USDJPY,USDCHF";
input bool AllowRealTrading=false;
input bool EnableRemoteControl=true;
input string BridgeURL="https://YOUR-SERVER.example.com";
input string ControlToken="";
input int MaxDailyLossBasisPoints=100; // 1% of start-of-day equity
input int MaxOpenPositions=3;
input int CooldownSeconds=120;
input int MaxSlippagePoints=15;
bool remoteEnabled=false;
datetime lastPoll=0;
datetime lastEntry[];
double dayStartEquity=0;
int dayId=-1;
string symbols[];
int fastH[],slowH[],rsiH[],macdH[],bandsH[];
datetime lastBars[];
int OnInit(){
 int n=StringSplit(Symbols,',',symbols);
 if(n<1||RiskPercent<=0||StopLossPoints<=0||TakeProfitPoints<=0||FastEMA>=SlowEMA||BreakoutLookback<3||MinVotes<1||MinVotes>5)return INIT_PARAMETERS_INCORRECT;
 ArrayResize(lastEntry,n);ArrayInitialize(lastEntry,0);ArrayResize(fastH,n);ArrayResize(slowH,n);ArrayResize(rsiH,n);ArrayResize(macdH,n);ArrayResize(bandsH,n);ArrayResize(lastBars,n);
 for(int i=0;i<n;i++){
  StringTrimLeft(symbols[i]);StringTrimRight(symbols[i]);
  if(!SymbolSelect(symbols[i],true))return INIT_FAILED;
  fastH[i]=iMA(symbols[i],PERIOD_M1,FastEMA,0,MODE_EMA,PRICE_CLOSE);
  slowH[i]=iMA(symbols[i],PERIOD_M1,SlowEMA,0,MODE_EMA,PRICE_CLOSE);
  rsiH[i]=iRSI(symbols[i],PERIOD_M1,RSIPeriod,PRICE_CLOSE);
  macdH[i]=iMACD(symbols[i],PERIOD_M1,12,26,9,PRICE_CLOSE);
  bandsH[i]=iBands(symbols[i],PERIOD_M1,20,0,2.0,PRICE_CLOSE);
  if(fastH[i]==INVALID_HANDLE||slowH[i]==INVALID_HANDLE||rsiH[i]==INVALID_HANDLE||macdH[i]==INVALID_HANDLE||bandsH[i]==INVALID_HANDLE)return INIT_FAILED;
  lastBars[i]=0;
 }
 trade.SetExpertMagicNumber(Magic);trade.SetDeviationInPoints(MaxSlippagePoints);EventSetTimer(2);return INIT_SUCCEEDED;
}
void OnDeinit(const int reason){EventKillTimer();for(int i=0;i<ArraySize(symbols);i++){IndicatorRelease(fastH[i]);IndicatorRelease(slowH[i]);IndicatorRelease(rsiH[i]);IndicatorRelease(macdH[i]);IndicatorRelease(bandsH[i]);}}
bool HasPosition(string s){for(int i=PositionsTotal()-1;i>=0;i--)if(PositionGetTicket(i)>0&&PositionGetString(POSITION_SYMBOL)==s&&(ulong)PositionGetInteger(POSITION_MAGIC)==Magic)return true;return false;}
double Lots(string s,ENUM_ORDER_TYPE type,double entry,double sl){
 double loss=0;
 if(!OrderCalcProfit(type,s,1.0,entry,sl,loss)||loss>=0)return 0;
 double risk=AccountInfoDouble(ACCOUNT_BALANCE)*RiskPercent/100.0;
 double step=SymbolInfoDouble(s,SYMBOL_VOLUME_STEP),minLot=SymbolInfoDouble(s,SYMBOL_VOLUME_MIN),maxLot=SymbolInfoDouble(s,SYMBOL_VOLUME_MAX);
 if(step<=0||minLot<=0||maxLot<=0)return 0;
 double raw=risk/MathAbs(loss),vol=MathFloor(MathMin(raw,maxLot)/step+1e-9)*step;
 if(vol<minLot)return 0;
 return NormalizeDouble(vol,8);
}
void Vote(bool buy,bool sell,int &bull,int &bear){if(buy)bull++;if(sell)bear++;}
void PollBridge(){
 if(!EnableRemoteControl){remoteEnabled=true;return;}
 if(TimeLocal()-lastPoll<5)return;
 lastPoll=TimeLocal();remoteEnabled=false; // fail closed on lost connection
 if(StringFind(BridgeURL,"https://")!=0||StringLen(ControlToken)<24)return;
 string mode=AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_REAL?"real":"demo";
 string url=BridgeURL+"/ea/poll?account="+IntegerToString(AccountInfoInteger(ACCOUNT_LOGIN))+"&mode="+mode+"&balance="+DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE),2)+"&equity="+DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY),2);
 char data[],reply[];string headers="X-Control-Token: "+ControlToken+"\r\n",responseHeaders;
 int code=WebRequest("GET",url,headers,3000,data,reply,responseHeaders);
 if(code==200){string result=CharArrayToString(reply);remoteEnabled=StringFind(result,"ON")>=0;}
}
int OpenCount(){int n=0;for(int i=PositionsTotal()-1;i>=0;i++)if(PositionGetTicket(i)>0&&(ulong)PositionGetInteger(POSITION_MAGIC)==Magic)n++;return n;}
bool DailyLossOK(){
 MqlDateTime dt;TimeToStruct(TimeCurrent(),dt);int today=dt.year*1000+dt.day_of_year;
 if(today!=dayId){dayId=today;dayStartEquity=AccountInfoDouble(ACCOUNT_EQUITY);}
 if(dayStartEquity<=0)return false;
 return AccountInfoDouble(ACCOUNT_EQUITY)>dayStartEquity*(1.0-MaxDailyLossBasisPoints/10000.0);
}
void OnTimer(){
 PollBridge();
 if(!remoteEnabled||!DailyLossOK()||OpenCount()>=MaxOpenPositions)return;
 if(AccountInfoInteger(ACCOUNT_TRADE_MODE)==ACCOUNT_TRADE_MODE_REAL&&!AllowRealTrading)return;
 if(!TerminalInfoInteger(TERMINAL_TRADE_ALLOWED)||!MQLInfoInteger(MQL_TRADE_ALLOWED))return;
 for(int i=0;i<ArraySize(symbols);i++){
  string s=symbols[i];MqlTick tick;
  if(!SymbolInfoTick(s,tick)||tick.ask<=0||tick.bid<=0||HasPosition(s)||TimeCurrent()-lastEntry[i]<CooldownSeconds)continue;
  double point=SymbolInfoDouble(s,SYMBOL_POINT),spread=(tick.ask-tick.bid)/point;
  if(point<=0||spread>MaxSpreadPoints)continue;
  datetime bar=iTime(s,PERIOD_M1,0);
  if(bar==0||bar==lastBars[i])continue;
  lastBars[i]=bar;
  double f[],g[],r[],m[],sig[],upper[],lower[],close[];
  ArraySetAsSeries(f,true);ArraySetAsSeries(g,true);ArraySetAsSeries(r,true);
  ArraySetAsSeries(m,true);ArraySetAsSeries(sig,true);ArraySetAsSeries(upper,true);ArraySetAsSeries(lower,true);ArraySetAsSeries(close,true);
  if(CopyBuffer(fastH[i],0,0,4,f)<4||CopyBuffer(slowH[i],0,0,4,g)<4||CopyBuffer(rsiH[i],0,0,4,r)<4||CopyBuffer(macdH[i],0,0,4,m)<4||CopyBuffer(macdH[i],1,0,4,sig)<4||CopyBuffer(bandsH[i],1,0,4,upper)<4||CopyBuffer(bandsH[i],2,0,4,lower)<4||CopyClose(s,PERIOD_M1,0,BreakoutLookback+3,close)<BreakoutLookback+3)continue;
  int bull=0,bear=0;
  if(UseEMA)Vote(f[2]<=g[2]&&f[1]>g[1],f[2]>=g[2]&&f[1]<g[1],bull,bear);
  if(UseRSI)Vote(r[2]<30&&r[1]>=30,r[2]>70&&r[1]<=70,bull,bear);
  if(UseMACD)Vote(m[2]<=sig[2]&&m[1]>sig[1],m[2]>=sig[2]&&m[1]<sig[1],bull,bear);
  if(UseBollinger)Vote(close[2]<lower[2]&&close[1]>=lower[1],close[2]>upper[2]&&close[1]<=upper[1],bull,bear);
  if(UseBreakout){double hi=-DBL_MAX,lo=DBL_MAX;for(int j=2;j<BreakoutLookback+2;j++){hi=MathMax(hi,iHigh(s,PERIOD_M1,j));lo=MathMin(lo,iLow(s,PERIOD_M1,j));}Vote(close[1]>hi,close[1]<lo,bull,bear);}
  if((bull<MinVotes&&bear<MinVotes)||bull==bear)continue;
  bool buy=bull>bear;
  ENUM_ORDER_TYPE type=buy?ORDER_TYPE_BUY:ORDER_TYPE_SELL;
  double entry=buy?tick.ask:tick.bid;
  int digits=(int)SymbolInfoInteger(s,SYMBOL_DIGITS);
  double sl=NormalizeDouble(entry+(buy?-1:1)*StopLossPoints*point,digits);
  double tp=NormalizeDouble(entry+(buy?1:-1)*TakeProfitPoints*point,digits);
  long stops=SymbolInfoInteger(s,SYMBOL_TRADE_STOPS_LEVEL);
  if(StopLossPoints<=stops+spread||TakeProfitPoints<=stops+spread)continue;
  double vol=Lots(s,type,entry,sl);if(vol<=0)continue;
  double margin=0;if(!OrderCalcMargin(type,s,vol,entry,margin)||margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE))continue;
  trade.SetTypeFillingBySymbol(s);
  bool ok=buy?trade.Buy(vol,s,0,sl,tp,"MultiStrategy M1"):trade.Sell(vol,s,0,sl,tp,"MultiStrategy M1");
  if(ok && (trade.ResultRetcode()==TRADE_RETCODE_DONE || trade.ResultRetcode()==TRADE_RETCODE_PLACED))lastEntry[i]=TimeCurrent();
  if(!ok)Print("Order rejected ",s," code=",trade.ResultRetcode()," ",trade.ResultRetcodeDescription());
 }
}
