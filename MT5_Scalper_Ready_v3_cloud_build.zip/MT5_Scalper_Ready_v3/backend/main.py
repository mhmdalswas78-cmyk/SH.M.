import os, sqlite3, time, secrets
from contextlib import contextmanager
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel

TOKEN = os.getenv('CONTROL_TOKEN')
if not TOKEN or len(TOKEN) < 24:
    raise RuntimeError('Set CONTROL_TOKEN to a random string of 24+ characters')
DB = os.getenv('DB_PATH','control.sqlite3')
app = FastAPI(title='MT5 Scalper Bridge v3')

@contextmanager
def conn():
    c=sqlite3.connect(DB,timeout=10)
    try:
        c.execute('CREATE TABLE IF NOT EXISTS states (account TEXT PRIMARY KEY, mode TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 0, updated INTEGER NOT NULL DEFAULT 0, heartbeat INTEGER NOT NULL DEFAULT 0, balance REAL NOT NULL DEFAULT 0, equity REAL NOT NULL DEFAULT 0)')
        c.commit()
        yield c
        c.commit()
    finally:c.close()

def auth(token):
    if not secrets.compare_digest(token or '', TOKEN):raise HTTPException(401,'Invalid token')

class Command(BaseModel):
    account: str
    enabled: bool
    mode: str

@app.post('/command')
def command(data:Command,x_control_token:str=Header(default='')):
    auth(x_control_token)
    if not data.account.isdigit() or len(data.account)>20 or data.mode not in ('demo','real'):raise HTTPException(400,'Invalid account or mode')
    with conn() as c:
        row=c.execute('SELECT mode FROM states WHERE account=?',(data.account,)).fetchone()
        if not row or row[0]!=data.mode:raise HTTPException(409,'Account not connected, or mode mismatch')
        c.execute('UPDATE states SET enabled=?,updated=? WHERE account=?',(int(data.enabled),int(time.time()),data.account))
    return {'account':data.account,'enabled':data.enabled,'mode':data.mode}

@app.get('/status')
def status(x_control_token:str=Header(default='')):
    auth(x_control_token)
    with conn() as c:
        rows=c.execute('SELECT account,mode,enabled,heartbeat,balance,equity FROM states ORDER BY account').fetchall()
    return {'accounts':[{'account':a,'mode':m,'enabled':bool(e),'online':time.time()-hb<25,'balance':b,'equity':q} for a,m,e,hb,b,q in rows]}

# Text-only EA endpoint: no JSON parser required in MQL5.
# An account can only register its actual terminal login and mode; use HTTPS and keep token secret.
@app.get('/ea/poll')
def poll(account:str,mode:str,balance:float=0,equity:float=0,x_control_token:str=Header(default='')):
    auth(x_control_token)
    if not account.isdigit() or len(account)>20 or mode not in ('demo','real'):raise HTTPException(400)
    with conn() as c:
        c.execute('INSERT OR IGNORE INTO states(account,mode,enabled) VALUES(?,?,0)',(account,mode))
        c.execute('UPDATE states SET mode=?,heartbeat=?,balance=?,equity=? WHERE account=?',(mode,int(time.time()),balance,equity,account))
        enabled=c.execute('SELECT enabled FROM states WHERE account=?',(account,)).fetchone()[0]
    return 'ON' if enabled else 'OFF'
